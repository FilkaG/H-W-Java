import java.util.*;

public class LS_6 {
    static Lesson_6 LS = new Lesson_6();
    public static void main(String[] args) {
        Set<Integer> integerSet = new HashSet<Integer>();

        for(int i = 0; i < 10; i++) {
            int number = new Random().nextInt(1000);
            System.out.print(number + " ");
            LS.Add(number);
            integerSet.add(number);
        }
        System.out.println();

        System.out.println("Size: " + LS.Sizee());


        TreeSet<Integer> sortedSet = new TreeSet<Integer>(new Comparator<Integer>()
        {
            public int compare(Integer i1,Integer i2)
            {
                return i2.compareTo(i1);
            }
        });

        Iterator<Integer> abc = integerSet.iterator();
        while(abc.hasNext()){int i = abc.next(); sortedSet.add(i); System.out.print(i+ " ");}
        System.out.println();
        System.out.println(sortedSet);














    }
}
