import java.util.TreeMap;

public class Lesson_6 {
    private TreeMap<Integer, Object> tm = new TreeMap<>();
    private static final Object SMF = new Object();
    public void Add ( int x){
        tm.put(x, SMF);
    }
    public int Sizee (){return tm.size();}

    public String Show (){
        return tm.keySet().toString();
    }


    }


